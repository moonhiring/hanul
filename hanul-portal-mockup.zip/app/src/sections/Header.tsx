import { useState } from "react";
import { Menu, Search, Globe } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetClose } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cities, i18n, type Lang } from "@/data";

interface Props {
  lang: Lang;
  setLang: (l: Lang) => void;
  city: string;
  setCity: (c: string) => void;
  onRegister: () => void;
}

const navItems = [
  { key: "stories" as const, href: "#stories" },
  { key: "directory" as const, href: "#directory" },
  { key: "life" as const, href: "#community" },
  { key: "community" as const, href: "#cheer" },
];

export default function Header({ lang, setLang, city, setCity, onRegister }: Props) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-paper/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 sm:px-6">
        <a href="#top" className="flex items-baseline gap-2">
          <span className="serif-display text-2xl font-black text-forest">한울</span>
          <span className="latin-serif text-[11px] font-semibold uppercase tracking-[0.3em] text-ink/70">Hanul</span>
        </a>

        <nav className="hidden items-center gap-7 lg:flex">
          {navItems.map((n) => (
            <a
              key={n.key}
              href={n.href}
              className="text-sm font-semibold text-ink/80 transition-colors hover:text-forest"
            >
              {i18n.nav[n.key][lang]}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Select value={city} onValueChange={setCity}>
            <SelectTrigger className="hidden h-9 w-[130px] rounded-full border-border bg-card text-xs font-semibold sm:flex">
              <Globe className="mr-1 h-3.5 w-3.5 text-forest" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {cities.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.ko}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <button
            onClick={() => setLang(lang === "ko" ? "en" : "ko")}
            className="hidden h-9 items-center rounded-full border border-border bg-card px-3 text-xs font-bold text-ink/80 transition-colors hover:border-forest hover:text-forest sm:flex"
            aria-label="언어 전환"
          >
            {lang === "ko" ? "KO" : "EN"}
          </button>

          <button
            onClick={onRegister}
            className="hidden h-9 items-center rounded-full bg-coral px-4 text-xs font-bold text-white transition-opacity hover:opacity-90 md:flex"
          >
            {i18n.nav.register[lang]}
          </button>

          {/* mobile menu */}
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <button className="flex h-10 w-10 items-center justify-center rounded-full border border-border bg-card lg:hidden" aria-label="메뉴 열기">
                <Menu className="h-5 w-5" />
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72 bg-paper">
              <div className="mt-8 flex flex-col gap-1">
                {navItems.map((n) => (
                  <SheetClose asChild key={n.key}>
                    <a
                      href={n.href}
                      className="rounded-lg px-3 py-3 text-lg font-bold text-ink transition-colors hover:bg-beige hover:text-forest"
                    >
                      {i18n.nav[n.key][lang]}
                    </a>
                  </SheetClose>
                ))}
                <div className="mt-4 border-t border-border pt-4">
                  <div className="flex items-center gap-2 px-3">
                    <Search className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">도시 선택</span>
                  </div>
                  <div className="mt-2 px-3">
                    <Select
                      value={city}
                      onValueChange={(v) => {
                        setCity(v);
                        setOpen(false);
                      }}
                    >
                      <SelectTrigger className="w-full rounded-full bg-card">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {cities.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.ko} · {c.country}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="mt-4 flex gap-2 px-3">
                    <button
                      onClick={() => setLang(lang === "ko" ? "en" : "ko")}
                      className="flex-1 rounded-full border border-border bg-card py-2.5 text-sm font-bold"
                    >
                      {lang === "ko" ? "English" : "한국어"}
                    </button>
                    <button
                      onClick={() => {
                        setOpen(false);
                        onRegister();
                      }}
                      className="flex-1 rounded-full bg-coral py-2.5 text-sm font-bold text-white"
                    >
                      {i18n.nav.register[lang]}
                    </button>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
