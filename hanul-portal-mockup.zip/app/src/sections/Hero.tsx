import { useState } from "react";
import { Search, BadgeCheck, ArrowDown } from "lucide-react";
import { cities, i18n, type Lang } from "@/data";

interface Props {
  lang: Lang;
  city: string;
  onSearch: (q: string) => void;
}

const cityDots = [
  { x: 78, y: 132, label: "뉴욕" },
  { x: 46, y: 118, label: "LA" },
  { x: 210, y: 74, label: "런던" },
  { x: 232, y: 82, label: "베를린" },
  { x: 340, y: 96, label: "도쿄" },
  { x: 322, y: 150, label: "호치민" },
  { x: 368, y: 208, label: "시드니" },
];

export default function Hero({ lang, city, onSearch }: Props) {
  const [q, setQ] = useState("");
  const cityName = cities.find((c) => c.id === city)?.ko ?? "뉴욕";

  return (
    <section id="top" className="relative overflow-hidden">
      {/* subtle dot grid */}
      <div
        aria-hidden
        className="absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage: "radial-gradient(#286d55 1px, transparent 1px)",
          backgroundSize: "26px 26px",
          maskImage: "radial-gradient(ellipse 90% 70% at 70% 30%, black, transparent)",
          WebkitMaskImage: "radial-gradient(ellipse 90% 70% at 70% 30%, black, transparent)",
        }}
      />
      <div className="relative mx-auto grid max-w-7xl gap-10 px-4 pb-16 pt-12 sm:px-6 lg:grid-cols-2 lg:items-center lg:gap-6 lg:pb-24 lg:pt-20">
        {/* manifesto */}
        <div>
          <p className="folio-label fade-up">{i18n.hero.kicker[lang]}</p>
          <h1 className="serif-display fade-up fade-up-delay-1 mt-5 break-keep text-[2.6rem] font-black leading-[1.15] text-ink sm:text-6xl lg:text-[4.2rem]">
            {i18n.hero.title1[lang]}
            <br />
            <span className="text-forest">{i18n.hero.title2[lang]}</span>
          </h1>
          <p className="latin-serif fade-up fade-up-delay-1 mt-3 text-xl italic text-coral-deep sm:text-2xl">
            {i18n.hero.titleLatin}
          </p>
          <p className="fade-up fade-up-delay-2 mt-6 max-w-md text-base leading-7 text-ink/70">
            {i18n.hero.body[lang]}
          </p>

          {/* search pill */}
          <form
            className="fade-up fade-up-delay-2 mt-8 flex max-w-md items-center rounded-full border border-border bg-card p-1.5 shadow-sm focus-within:ring-2 focus-within:ring-forest/25"
            onSubmit={(e) => {
              e.preventDefault();
              onSearch(q);
            }}
          >
            <Search className="ml-3 h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={i18n.hero.searchPlaceholder[lang]}
              className="w-full min-w-0 bg-transparent px-3 py-2 text-sm outline-none placeholder:text-muted-foreground/70"
              aria-label={i18n.hero.searchBtn[lang]}
            />
            <button
              type="submit"
              className="shrink-0 rounded-full bg-forest px-5 py-2.5 text-sm font-bold text-cream transition-opacity hover:opacity-90"
            >
              {i18n.hero.searchBtn[lang]}
            </button>
          </form>

          {/* stats */}
          <div className="fade-up fade-up-delay-3 mt-10 flex gap-8 border-t border-border pt-6 sm:gap-12">
            <div>
              <p className="serif-display text-3xl font-black text-ink">42</p>
              <p className="mt-1 text-xs font-semibold text-muted-foreground">{i18n.hero.statCities[lang]}</p>
            </div>
            <div>
              <p className="serif-display text-3xl font-black text-ink">12,847</p>
              <p className="mt-1 text-xs font-semibold text-muted-foreground">{i18n.hero.statBiz[lang]}</p>
            </div>
            <div>
              <p className="serif-display text-3xl font-black text-ink">386</p>
              <p className="mt-1 text-xs font-semibold text-muted-foreground">{i18n.hero.statStories[lang]}</p>
            </div>
          </div>
        </div>

        {/* globe visual */}
        <div className="relative mx-auto w-full max-w-[440px]">
          <svg viewBox="0 0 420 300" className="w-full" role="img" aria-label="세계 각지의 한인 도시를 잇는 선">
            {/* arcs */}
            <path d="M78 132 Q 130 40 210 74" fill="none" stroke="#286d55" strokeWidth="1.5" className="arc-draw" />
            <path d="M210 74 Q 280 30 340 96" fill="none" stroke="#286d55" strokeWidth="1.5" className="arc-draw arc-draw-2" />
            <path d="M340 96 Q 380 150 368 208" fill="none" stroke="#e24e67" strokeWidth="1.5" className="arc-draw arc-draw-3" />
            <path d="M46 118 Q 200 230 368 208" fill="none" stroke="#286d55" strokeWidth="1" strokeDasharray="3 6" opacity="0.5" />
            {/* dots */}
            {cityDots.map((d, i) => (
              <g key={d.label}>
                <circle cx={d.x} cy={d.y} r="4.5" fill={i === 2 ? "#e24e67" : "#286d55"} className="city-dot" style={{ animationDelay: `${i * 0.4}s` }} />
                <text x={d.x + 10} y={d.y + 4} fontSize="11" fill="#222222" opacity="0.75" fontWeight="600">
                  {d.label}
                </text>
              </g>
            ))}
          </svg>

          {/* floating cards */}
          <div className="fade-up fade-up-delay-2 absolute -left-2 bottom-2 w-44 rounded-2xl border border-border bg-card p-3 shadow-md sm:-left-6">
            <div className="flex items-center gap-1.5">
              <BadgeCheck className="h-4 w-4 text-forest" />
              <span className="text-[11px] font-bold text-forest">인증 업체</span>
            </div>
            <p className="serif-display mt-1.5 text-sm font-bold">달달 베이커리</p>
            <p className="text-[11px] text-muted-foreground">시드니 · 리뷰 342</p>
          </div>
          <div className="fade-up fade-up-delay-3 absolute -bottom-2 right-0 w-36 rounded-2xl bg-forest p-3 shadow-lg sm:-right-4 sm:bottom-auto sm:top-0">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-cream/70">지금 {cityName}에서는</p>
            <p className="mt-1 text-xs font-semibold leading-5 text-cream">새 구인 공고 3건과 주말 모임이 올라왔어요</p>
          </div>

          <a
            href="#stories"
            className="absolute -bottom-8 left-1/2 hidden h-11 w-11 -translate-x-1/2 items-center justify-center rounded-full border border-border bg-card text-ink transition-colors hover:bg-beige lg:flex"
            aria-label="아래로 스크롤"
          >
            <ArrowDown className="h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
