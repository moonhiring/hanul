import { useState } from "react";
import Header from "@/sections/Header";
import Hero from "@/sections/Hero";
import Ticker from "@/sections/Ticker";
import Stories from "@/sections/Stories";
import Directory from "@/sections/Directory";
import Community from "@/sections/Community";
import Cheer from "@/sections/Cheer";
import Footer from "@/sections/Footer";
import RegisterDialog from "@/components/RegisterDialog";
import { Toaster } from "@/components/ui/sonner";
import type { Lang } from "@/data";
import "../App.css";

export default function Home() {
  const [lang, setLang] = useState<Lang>("ko");
  const [city, setCity] = useState("nyc");
  const [registerOpen, setRegisterOpen] = useState(false);
  const [query, setQuery] = useState("");

  const handleSearch = (q: string) => {
    setQuery(q);
    document.getElementById("directory")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-dvh">
      <Header lang={lang} setLang={setLang} city={city} setCity={setCity} onRegister={() => setRegisterOpen(true)} />
      <main>
        <Hero lang={lang} city={city} onSearch={handleSearch} />
        <Ticker />
        <Stories />
        <Directory query={query} onClearQuery={() => setQuery("")} />
        <Community />
        <Cheer />
      </main>
      <Footer onRegister={() => setRegisterOpen(true)} />
      <RegisterDialog open={registerOpen} onOpenChange={setRegisterOpen} />
      <Toaster position="bottom-center" />
    </div>
  );
}
