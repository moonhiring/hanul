export type Lang = "ko" | "en";

export const cities = [
  { id: "nyc", ko: "뉴욕", en: "New York", country: "미국" },
  { id: "la", ko: "로스앤젤레스", en: "Los Angeles", country: "미국" },
  { id: "toronto", ko: "토론토", en: "Toronto", country: "캐나다" },
  { id: "vancouver", ko: "밴쿠버", en: "Vancouver", country: "캐나다" },
  { id: "sydney", ko: "시드니", en: "Sydney", country: "호주" },
  { id: "melbourne", ko: "멜버른", en: "Melbourne", country: "호주" },
  { id: "london", ko: "런던", en: "London", country: "영국" },
  { id: "berlin", ko: "베를린", en: "Berlin", country: "독일" },
  { id: "tokyo", ko: "도쿄", en: "Tokyo", country: "일본" },
  { id: "hcmc", ko: "호치민", en: "Ho Chi Minh", country: "베트남" },
];

export const i18n = {
  nav: {
    stories: { ko: "이야기", en: "Stories" },
    directory: { ko: "업소록", en: "Directory" },
    life: { ko: "일자리·부동산", en: "Jobs & Homes" },
    community: { ko: "커뮤니티", en: "Community" },
    register: { ko: "업체 등록", en: "List a business" },
  },
  hero: {
    kicker: { ko: "디아스포라 포털 · 750만 재외동포", en: "Diaspora portal · 7.5M Koreans abroad" },
    title1: { ko: "세상 모든 한인을", en: "One warm square" },
    title2: { ko: "잇는 따뜻한 광장", en: "for every Korean," },
    titleLatin: "Every Korean, everywhere.",
    body: {
      ko: "뉴욕의 첫 가게, 시드니의 새 일자리, 런던의 동네 모임까지. 흩어져 있던 한인의 하루를 한 곳에 모았습니다.",
      en: "From a first shop in New York to a new job in Sydney — the everyday of the Korean diaspora, gathered in one place.",
    },
    searchPlaceholder: { ko: "뉴욕 한식당, 시드니 치과, 런던 변호사…", en: "Try “Korean bakery in Sydney”…" },
    searchBtn: { ko: "검색", en: "Search" },
    statCities: { ko: "개 도시", en: "cities" },
    statBiz: { ko: "인증 업체", en: "verified businesses" },
    statStories: { ko: "이번 달 새 이야기", en: "new stories this month" },
  },
};

export const tickerItems = [
  { city: "뉴욕", text: "한식당 ‘온지음’이 인증 업체로 등록됐습니다" },
  { city: "시드니", text: "IT 개발자 구인 공고가 올라왔습니다" },
  { city: "런던", text: "주말 한인 축구 모임, 새 멤버 4명 모집 중" },
  { city: "토론토", text: "김치 담그기 클래스 이번 주 토요일" },
  { city: "멜버른", text: "한인 치과 ‘미소’ 첫 방문 20% 할인" },
  { city: "호치민", text: "한인 부동산 매물 12건 업데이트" },
  { city: "베를린", text: "유학생 멘토링 매칭 3쌍 성사" },
  { city: "도쿄", text: "재일동포 3세 작가 인터뷰 공개" },
];

export interface Story {
  id: number;
  tag: string;
  title: string;
  excerpt: string;
  body: string;
  author: string;
  city: string;
  date: string;
  readTime: string;
  cheers: number;
}

export const stories: Story[] = [
  {
    id: 1,
    tag: "이번 주의 이야기",
    title: "맨해튼 한복판에서 문을 연 68세 초보 사장님의 김밥집",
    excerpt:
      "은퇴 후 이민 24년 만에 처음 가게를 열었습니다. “늦었다고 생각했는데, 동네 사람들이 매일 응원하러 와요.”",
    body: "은퇴 후 이민 24년 만에 처음 가게를 열었습니다. 첫 달은 하루 매출이 80달러였지만, 한인 커뮤니티의 입소문과 동네 단골들 덕분에 지금은 점심시간마다 줄이 생깁니다. “늦었다고 생각했는데, 동네 사람들이 매일 응원하러 와요. 김밥 한 줄에 마음을 담으면 통하더라고요.” 옹기종기 앉은 손님들 사이에서 사장님은 오늘도 가장 바쁜 사람입니다.",
    author: "김온유",
    city: "뉴욕",
    date: "2026.10.28",
    readTime: "6분",
    cheers: 1284,
  },
  {
    id: 2,
    tag: "창업",
    title: "시드니에서 한국식 베이커리로 웨이팅 맛집이 된 90년생 자매",
    excerpt: "소금빵과 인절미 크루아상. 낯선 조합이 동네 아침 풍경을 바꿨습니다.",
    body: "소금빵과 인절미 크루아상. 낯선 조합이 동네 아침 풍경을 바꿨습니다. 자매는 매일 새벽 4시에 반죽을 시작합니다. “현지 손님이 ‘이거 한국 빵이에요?’라고 물을 때가 제일 뿌듯해요.”",
    author: "이하늘·이바다",
    city: "시드니",
    date: "2026.10.24",
    readTime: "5분",
    cheers: 862,
  },
  {
    id: 3,
    tag: "정착",
    title: "베를린 유학 8년, 이제는 후배들의 멘토가 된 엔지니어",
    excerpt: "월세 계약서 한 장 못 읽던 시절에서, 40명의 멘티를 둔 지금까지.",
    body: "월세 계약서 한 장 못 읽던 시절에서, 40명의 멘티를 둔 지금까지. 그는 매주 일요일 카페에서 무료 상담을 엽니다. “저도 누군가의 도움으로 버텼으니까요. 돌려주는 것뿐입니다.”",
    author: "박도현",
    city: "베를린",
    date: "2026.10.19",
    readTime: "7분",
    cheers: 733,
  },
  {
    id: 4,
    tag: "세대 공감",
    title: "한국어를 잊어가는 딸에게, 아빠가 시작한 일요일 글쓰기 교실",
    excerpt: "2세 딸과 아빠가 매주 주고받는 편지가 쌓여 한 권의 책이 되었습니다.",
    body: "2세 딸과 아빠가 매주 주고받는 편지가 쌓여 한 권의 책이 되었습니다. “처음엔 세 문장 쓰는 것도 힘들어했어요. 지금은 딸이 먼저 편지를 건넵니다.”",
    author: "정태영",
    city: "토론토",
    date: "2026.10.12",
    readTime: "5분",
    cheers: 1105,
  },
];

export type BizCategory = "맛집" | "뷰티" | "의료" | "법률·회계" | "교육" | "부동산";
export const bizCategories: BizCategory[] = ["맛집", "뷰티", "의료", "법률·회계", "교육", "부동산"];

export interface Business {
  id: number;
  name: string;
  initial: string;
  category: BizCategory;
  city: string;
  rating: number;
  reviews: number;
  verified: boolean;
  tagline: string;
  featured?: boolean;
}

export const businesses: Business[] = [
  { id: 1, name: "온지음", initial: "온", category: "맛집", city: "뉴욕", rating: 4.9, reviews: 214, verified: true, tagline: "제철 식재료로 차리는 한식 오마카세", featured: true },
  { id: 2, name: "미소 치과", initial: "미", category: "의료", city: "멜버른", rating: 4.8, reviews: 167, verified: true, tagline: "한국어 상담 가능한 가족 치과", featured: true },
  { id: 3, name: "한결 법률사무소", initial: "한", category: "법률·회계", city: "토론토", rating: 4.9, reviews: 98, verified: true, tagline: "이민·비자 전문 15년 경력", featured: true },
  { id: 4, name: "달달 베이커리", initial: "달", category: "맛집", city: "시드니", rating: 4.7, reviews: 342, verified: true, tagline: "매일 새벽 굽는 소금빵과 인절미 크루아상" },
  { id: 5, name: "숲 피부관리", initial: "숲", category: "뷰티", city: "로스앤젤레스", rating: 4.8, reviews: 156, verified: false, tagline: "K-뷰티 정통 관리, 첫 방문 체험권" },
  { id: 6, name: "가람 한국어학당", initial: "가", category: "교육", city: "런던", rating: 4.9, reviews: 88, verified: true, tagline: "2세 교육부터 성인 비즈니스 한국어까지" },
  { id: 7, name: "두레 부동산", initial: "두", category: "부동산", city: "밴쿠버", rating: 4.6, reviews: 121, verified: true, tagline: "신규 이민자 정착 렌트 전문" },
  { id: 8, name: "모아 회계", initial: "모", category: "법률·회계", city: "호치민", rating: 4.7, reviews: 64, verified: false, tagline: "현지 법인 설립·세무 원스톱" },
  { id: 9, name: "초록 소아과", initial: "초", category: "의료", city: "도쿄", rating: 4.8, reviews: 193, verified: true, tagline: "일본어가 어려운 부모님들의 단골" },
  { id: 10, name: "바다 미용실", initial: "바", category: "뷰티", city: "시드니", rating: 4.7, reviews: 209, verified: true, tagline: "한국 스타일 시세이도 펌 전문" },
  { id: 11, name: "마루 국밥", initial: "마", category: "맛집", city: "베를린", rating: 4.6, reviews: 277, verified: false, tagline: "유학생의 위로, 24시간 순댓국" },
  { id: 12, name: "하늘 공인중개", initial: "하", category: "부동산", city: "뉴욕", rating: 4.8, reviews: 95, verified: true, tagline: "퀸즈·뉴저지 매매 전문" },
];

export interface LifePost {
  id: number;
  kind: "구인" | "부동산" | "모임";
  title: string;
  meta: string;
  time: string;
  comments: number;
  cheers: number;
}

export const lifePosts: Record<string, LifePost[]> = {
  nyc: [
    { id: 1, kind: "구인", title: "맨해튼 한식당 주방보조 · 시급 $22", meta: "온지음 · 풀타임", time: "10분 전", comments: 8, cheers: 21 },
    { id: 2, kind: "부동산", title: "플러싱 원베드 렌트 · 즉시 입주", meta: "하늘 공인중개", time: "1시간 전", comments: 5, cheers: 12 },
    { id: 3, kind: "모임", title: "센트럴파크 아침 러닝 크루 (토요일)", meta: "32명 참여 중", time: "3시간 전", comments: 14, cheers: 56 },
    { id: 4, kind: "구인", title: "뉴저지 물류센터 파트타임 관리자", meta: "주 3일 · 경력 무관", time: "5시간 전", comments: 3, cheers: 9 },
  ],
  sydney: [
    { id: 5, kind: "구인", title: "IT 개발자 (React) · 비자 스폰서 가능", meta: "시드니 스타트업", time: "방금", comments: 21, cheers: 74 },
    { id: 6, kind: "부동산", title: "스트라스필드 역세권 쉐어하우스", meta: "주 $320 · 빌 포함", time: "40분 전", comments: 6, cheers: 11 },
    { id: 7, kind: "모임", title: "워홀러 정보 교류 밋업 (11월)", meta: "본다이 비치", time: "2시간 전", comments: 18, cheers: 43 },
  ],
  london: [
    { id: 8, kind: "모임", title: "한인 축구팀 '태극FC' 신입 모집", meta: "매주 일요일 오전", time: "20분 전", comments: 9, cheers: 38 },
    { id: 9, kind: "구인", title: "한국어 튜터 · 시급 £25부터", meta: "가람 한국어학당", time: "2시간 전", comments: 4, cheers: 15 },
    { id: 10, kind: "부동산", title: "뉴몰든 한인타운 2베드 플랫", meta: "월 £1,850", time: "어제", comments: 7, cheers: 19 },
  ],
  hcmc: [
    { id: 11, kind: "구인", title: "한인 마트 매장 관리 매니저", meta: "푸미흥 · 경력 우대", time: "1시간 전", comments: 2, cheers: 8 },
    { id: 12, kind: "부동산", title: "타오디엔 아파트 월세 · 풀옵션", meta: "$900 · 수영장", time: "4시간 전", comments: 11, cheers: 23 },
    { id: 13, kind: "모임", title: "주말 골프 라운딩 멤버 구합니다", meta: "핸디 무관", time: "어제", comments: 6, cheers: 17 },
  ],
};

export const cheerPosts = [
  {
    id: 1,
    name: "최은서",
    meta: "런던 · 유학 3년차",
    text: "내년이면 한국어가 약한 2세 아이들을 위한 그림책 도서관을 엽니다. 후원이 아니라 응원 한마디면 충분해요.",
    cheers: 892,
  },
  {
    id: 2,
    name: "강태산",
    meta: "호치민 · 자영업 1년차",
    text: "한인이 아무도 오지 않던 골목에 떡볶이 가게를 열었습니다. 이번 달 처음으로 흑자를 냈어요. 포기하지 않길 잘했습니다.",
    cheers: 1204,
  },
  {
    id: 3,
    name: "유미나",
    meta: "멜버른 · 간호사",
    text: "야간 근무 끝에 쓰는 이민 생활 에세이가 벌써 40편째. 내년엔 책으로 묶어 같은 길을 걷는 분들께 선물하고 싶습니다.",
    cheers: 677,
  },
];
