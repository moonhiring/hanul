# 한울 HANUL — 프로젝트 인수인계 노트

새 작업 공간에서 이어서 작업할 때 참고하세요.

## 프로젝트 개요
- **한울(HANUL)**: 전 세계 재외 한인을 위한 모바일 친화 커뮤니티 + 비즈니스 리스팅 포털 목업
- 스택: React + TypeScript + Vite + Tailwind + shadcn/ui (프론트엔드 목업, 백엔드 없음)
- 실행: `npm install` → `npm run dev`(개발) / `npm run build`(빌드, 산출물 `dist/`)

## 디자인 시스템
- 컬러: 포레스트 그린 `#286d55`(메인) / 크림 `#f6dece` / 베이지 `#e9e7e1` / 코랄 `#e24e67`(포인트) / 잉크 `#222`
- 폰트: Fraunces(영문 세리프) + Noto Serif KR(한글 디스플레이) + Noto Sans KR(UI)
- 커스텀 토큰: `tailwind.config.js`의 forest/cream/coral/beige/ink/paper, `src/index.css`의 유틸리티(folio-label, serif-display, ticker, pulse-dot 등)

## 구조
- `src/data.ts` — 모든 목업 데이터(도시, 스토리, 업체, 구인/부동산/모임, 응원 게시글) + 한/영 문구. 실데이터 연동 시 이 파일을 API 호출로 교체
- `src/sections/` — Header, Hero, Ticker, Stories, Directory, Community, Cheer, Footer
- `src/components/RegisterDialog.tsx` — 업체 등록 폼 모달
- `src/pages/Home.tsx` — 상태(언어/도시/검색어/등록모달) 총괄

## 확정된 기획 방향 (사용자 요구)
- 20~60대 전 연령 커버, 모바일 친화, 아주 현대적이고 세련된 디자인
- "좋은 이야기만" 담는 긍정 큐레이션 — 응원/행복 콘텐츠가 핵심 차별화
- 비즈니스 리스팅 + 커뮤니티 포털 결합

## 다음 작업 후보 (미결정)
1. 백엔드(DB/로그인) 추가 — 샘플 데이터를 실제 데이터로
2. 데이터 수집 전략: 무단 크롤링 대신 공개 데이터 + RSS 링크 집계 + 업주 클레임 시스템 권장 (법적 리스크 때문)
3. 브랜드 네이밍/컬러 조정, 실제 사진 적용

## 검증 상태
- 빌드 통과, 콘솔 에러 0, 모바일 375px 대응 확인 (2026-11-01)
